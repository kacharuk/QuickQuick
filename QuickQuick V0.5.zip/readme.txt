Use of this software indicates you accept the terms of this license agreement and warranty.

1. Disclaimer of Warranty
QuickQuick (this software) is provided "as-is" and without warranty of any kind, express, implied or otherwise, including without limitation, any warranty of merchantability or fitness for a particular purpose. 
In no event shall the author of this software be held liable for data loss, damages, loss of profits or any other kind of loss while using or misusing this software.

2. Version Information
QuickQuick Version 0.5
Release Date : 26 May 2021

3. License
This software is released under the GPL Version 3

4. More Information
Visit https://www.kacharuk.com for more information

